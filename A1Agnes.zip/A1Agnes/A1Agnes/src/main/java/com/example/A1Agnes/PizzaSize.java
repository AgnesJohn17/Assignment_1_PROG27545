// Student ID: 991783138
// Name: Agnes Sania John

package com.example.A1Agnes;

public enum PizzaSize {
    SMALL,
    MEDIUM,
    LARGE
}
