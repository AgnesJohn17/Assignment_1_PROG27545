package com.example.A1Agnes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A1AgnesApplicationTests {

	@Test
	void contextLoads() {
	}

}
